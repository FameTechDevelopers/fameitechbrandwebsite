const images = [
    "../../assets/rosemount.webp",
    "../assets/abstract-logo.jpg"
    ]

export default images