const logobranding =[
    {
        "title":"Basic",
        "price":499,
        "list":["5 Pages Website","Custom Layout Design","3 Banner Designs", "5 Stock Photos","Free Favicon Design","Free Google Sitemap","Unlimited Revisions","Cross-Browser Compatibility"]
       
    },
    {
        "title":"Standard",
        "price":749,
        "list":["Up to 10 Unique Pages Website/ CMS / Admin Panel Integration","5+ Stock Photos & Banner Designs","Free Social Media Integration", "Free Favicon Design","Free Google Sitemap","Unlimited Revisions","Cross-Browser Compatibility"]
       
    },
    {
        "title":"E-Commerce",
        "price":999,
        "list":["Custom Ecommerce Website Up to 50 Products","CMS/ Admin Panel Integration Full Mobile Responsive","Shopping Cart Integration", "Payment Gateway Integration","Product Listing & Management","Order Management & Tracking"]
       
    },
    {
        "title":"Corporate",
        "price":999,
        "list":["Up to 15 Unique Pages Website Custom Made, Interactive & Dynamic Design","Customized WordPress or PHP Development", "Full Mobile Responsive","Interactive Sliding Banners Up to 10","Custom Made Banners","Upto 15 Professional Emails","Complete Source Files","Complete Deployment"]
       
    }
]

export default logobranding