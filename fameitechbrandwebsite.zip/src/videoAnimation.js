const video = [
    {
        "title":"Basic",
        "price":499,
        "list":[" 60 seconds","Custom Layout Design.","Script Writing","Detail Storyboard","Professional Voice over","Impressive Animation","Royalty free BG & SFX","File Delivered in HD 720p"]
    },
    {
        "title":"Startup",
        "price":799,
        "list":["60 seconds","Script Writing","Storyboarding","Detail illustrations","Professional Voice over","Impressive Animation","Royalty free BG & SFX","3 weeks Deadline"]
    },    
    {
        "title":"Professional",
        "price":999,
        "list":["60 seconds","Script Writing","Storyboarding","Detail illustrations","Professional Voice over","Impressive Animation","File Delivered in HD 1080p","MP4, MOV, WAV"]      
     },
    {
        "title":"Deluxe",
        "price":599,
        "list":["60 seconds"," 2 Concepts + premium scriptwriting","Storyboarding","Detail illustrations","Impressive Animation","Royalty free BG & SFX"," File Delivered in HD 1080p","Unlimited revisions","MP4, MOV, WAV, GIF"
        ]
    }
]

export default video