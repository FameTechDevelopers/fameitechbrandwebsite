const price = [
    {
        title:"Basic",
        price:499,
        list:["Professional Logo","4 Logo Concepts","6 Revisions","Custom Logo","Vector PDF File","48 hours Delivery","JPG + PDF + PNG","100% Ownership","Startup Branding","Business Card Design","Letterhead Design","Envelope Design","100% Ownership","1 Page HTML","1 Page Static Website","Jquery Slider Banner","W3C Certified HTML","UI Design","3 Banner Design","Favicon","SEO Friendly Design" ]
       
    },
    {
        title:"Standard",
        price:699,
        list:["Premium Logo ","6 Logo Concepts","Unlimited Revision" ,"Custom Logo","Vector EPS , PDF file","24-48 H Delivery","JPG + PDF + PNG + EPS","100% Ownership", "Professional Branding","Business Card Design","Letterhead Design","Envelope Design","Email Signature","2 Social Covers " ,"HTML Website", "5 Page Static Website","Jquery Slider Banner","W3C Certified HTML","UI Design","3 Banner Design","Favicon","SEO Friendly Design"]
    },
    {
        title:"Prime",
        price:1299,
        list:["Deluxe Logo","Unlimited Logo Concepts","Unlimited Revision","Custom Logo","Editable Vector Ai","24-48 H Delivery", "Vector EPS, PDF","JPG + PDF + PNG + EPS + AI","100% Ownership","Business Card Design" ,"1 Page HTML","1 Page HTML","Corporate Branding","Business Card Design","Letterhead Design","Envelope Design"," Email Signature","2 Social Covers","T-Shirt Design","Web Banner Design",
        "CMS Website" ,"5 Pages Dynamic Website","Web Development","W3C Certified HTML","Web Design & UI","10 Stock Images","5 Banner Designs","Advance UI Effects","SEO Friendly Design","SEO Friendly Sitemap","On Page Optimization","Social Media Inte","4 Social Platforms"
    ]
    },
    {
        title:"Corporate",
        price:999,
        list:["Deluxe Logo","Unlimited Logo Concepts","Unlimited Revision","Custom Logo","Editable Vector Ai","24-48 H Delivery", "Vector EPS, PDF","JPG + PDF + PNG + EPS + AI","100% Ownership","Business Card Design" ,"1 Page HTML","1 Page HTML","Ultimate Branding","Business Card Design","Letterhead Design","Envelope Design"," Email Signature","2 Social Covers","T-Shirt Design","Web Banner Design", "Signage Design","Car Stickers Design","E-commerce Website", "Web Development"," W3C Certified HTML","Admin Panel Support", "Mobile Responsive Layout"," Customers Login Area","Cart Integration","Pay. Module Integration"," Inventory Mangement","Unltd. Products & Cate","Easy Product Search","Product Reviews","Web Design & UI"," 15 Stock Images","8 Banner Designs"," Favicon","Advance UI Effects"," Basic Search Engine Submission","SEO Friendly Design"," SEO Friendly Sitemap","Analytics Integration","On Page Optimization","Social Media Integration"," 4 Social Platforms "]
    }
]

export default price