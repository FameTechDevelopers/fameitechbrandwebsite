const logo = [
    {
        "title":"Basic",
        "price":50,
        "list":["4 Original Logo Concepts","2 Dedicated Logo Designers","4 Revisions", "With Grey Scale Format","Email Signature Design"]
       
    },
    {
        "title":"Standard",
        "price":129,
        "list":["12 Original Logo Concepts","4 Dedicated Logo Designers","Unlimited Revisions","Stationery Design (Business Card, Letterhead, Envelope)","Email Signature Designs","With Grey Scale Format"]
        
    },
    {
        "title":"Prime",
        "price":299,
        "list":["Unlimited Original Logo Concepts 8 Dedicated Logo Designers","Unlimited Revisions","Stationery Design (Business Card, Letterhead, Envelope)","500 Business Cards","With Grey Scale Format"]
        
    },
    {
        "title":"Deluxe",
        "price":599,
        "list":["Unlimited Original Logo Concepts 10 Dedicated Logo Designers","Unlimited Revisions","Stationery Design (Business Card, Letterhead, Envelope)","500 Business Cards","With Grey Scale Format"]
        
    }
]

export default logo