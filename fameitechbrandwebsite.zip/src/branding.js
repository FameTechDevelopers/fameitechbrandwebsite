const branding = [
    {
        "title":"Basic",
        "price":99,
        "list":["Business Card Design","Letter head Design","4 Revisions", "Envelope Design","MS Word Letterhead","Email Signature Design","Invoice Design","Facebook Banner Design","Youtube Banner Design","Twitter Banner Design","Linkedin Banner Design","Logo Watermark"]
       
    },
    {
        "title":"Standard",
        "price":139,
        "list":["Business Card Design","Letter head Design","4 Revisions", "Envelope Design","MS Word Letterhead","Email Signature Design","Invoice Design","Facebook Banner Design","Youtube Banner Design","Twitter Banner Design","Linkedin Banner Design","Logo Watermark","Favicon Design","Polo/T-Shirt Design","Cap/Hat Design"]

    },
    {
        "title":"Prime",
        "price":249,
        "list":["Business Card Design","Letter head Design","4 Revisions", "Envelope Design","MS Word Letterhead","Email Signature Design","Invoice Design","Facebook Banner Design","Youtube Banner Design","Twitter Banner Design","Linkedin Banner Design","Logo Watermark","Favicon Design","Polo/T-Shirt Design","Cap/Hat Design","Bag Design","Signage Design","Flyer Design"]

    },
    {
        "title":"Deluxe",
        "price":599,
        "list":["Business Card Design","Letter head Design","4 Revisions", "Envelope Design","MS Word Letterhead","Email Signature Design","Invoice Design","Facebook Banner Design","Youtube Banner Design","Twitter Banner Design","Linkedin Banner Design","Logo Watermark","Favicon Design","Polo/T-Shirt Design","Cap/Hat Design","Bag Design","Signage Design","Flyer Design","Car Wrap/Vinyl Design","PPT Design","Magnet Design","Door Sign Design","Menu Design","Mug/Cup Design"]
       
    }
]

export default branding