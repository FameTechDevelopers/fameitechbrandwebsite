const brandlogo = [
    {
        "title":"Basic",
        "price":89,
        "list":["Basic Logo","2 Logo Concepts","3 Revisions", "No High Res. files","48 hours Delivery","100% Ownership","JPG + PNG","Startup Branding","Business Card Design","Letterhead Design","Envelope Design","100% Ownership"]
       
    },
    {
        "title":"Standard",
        "price":219,
        "list":["Professional Logo","4 Logo Concepts","6 Revisions", "Custom Logo","Vector PDF File","48 hours Delivery","JPG + PDF + PNG","100% Ownership","Corporate Branding","Business Card Design","Letterhead Design","Envelope Design","Email Signature","2 Social Covers","T-Shirt Design","Web Banner Design"]

    },    
    {
        "title":"Prime",
        "price":249,
        "list":[" Premium Logo","6 Logo Concepts","Unlimited Revision", "Custom Logo"," Vector EPS,PDF file","  24-48 H Delivery","  JPG + PDF + PNG + EPS","100% Ownership"," Ultimate Branding","Business Card Design","Letterhead Design","Envelope Design","Email Signature","2 Social Covers","T-Shirt Design","Web Banner Design","Signage Design","Car Stickers Design"]
       
     },
    {
        "title":"Deluxe",
        "price":599,
        "list":["Deluxe Logo","Unlimited Logo Concepts","Unlimited Revision", "Custom Logo","Editable Vector Ai" ," PDF file","24-48 H Delivery","JPG + PDF + PNG + EPS + AI","100% Ownership", "Business Card Design","Ultimate Branding","Business Card Design","Letterhead Design","Envelope Design","Email Signature","4 Social Covers","T-Shirt Design","Web Banner Design","Signage Design","Car Stickers Design" ]
       
    }
]

export default brandlogo